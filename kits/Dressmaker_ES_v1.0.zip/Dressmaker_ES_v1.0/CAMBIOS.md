# Versiones de Dressmaker ES

## v1.0 — 2026-10-03

Primera versión numerada para el build de Steam 25508059. Contiene las mismas tablas y archivos del paquete local `v1_prueba`. No se alteró el contenido de la traducción entre esos dos paquetes.

- Añade **Español** al selector, conservando los idiomas existentes. La etiqueta empieza con mayúscula y utiliza el tono del botón original.
- Incorpora `UI_es` (208 entradas), `Content_es` (1930), `Dialogue_es` (3677) y `Tutorial_es` (71): 5365 traducciones y 521 entradas internas/demo conservadas en inglés.
- Recupera el título mediante `Images_es`; las cinco imágenes de esa tabla reutilizan las referencias inglesas del juego.
- Mantiene las fuentes originales. El texto español usa tres puntos (`...`) donde la fuente no cubre el glifo de puntos suspensivos.
- Incluye instrucciones de instalación, restauración, manifiesto y SHA-256 de cada archivo.

El usuario confirmó que la versión instalada en Steam **se ve bien**, incluido el título confirmado antes. Esa observación no cubre una partida completa: siguen pendientes la revisión de diálogos, tutoriales, textos largos, resoluciones y persistencia después de reiniciar.

## v1_prueba — 2026-10-03

Paquete local previo que contiene los mismos siete archivos activos y los originales de restauración. Se conserva como antecedente; `v1.0` es la versión numerada vigente.

## Criterio para próximas versiones

Usar `v1.1`, `v1.2`, etc. cuando cambien textos, tablas, selector, imágenes o compatibilidad. Conservar cada ZIP y anotar cambios, build de Steam y resultados de revisión. Reconstruir desde la copia prístina correspondiente si Steam actualiza el juego; no mezclar bundles de builds distintos.
